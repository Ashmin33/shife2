# Birthday Shifu 🎉

This is a special birthday surprise website.

## 🚀 Deploy

1. Upload files to a GitHub repo named `shife`.
2. Go to [Vercel](https://vercel.com), import the repo, and click **Deploy**.
3. Done 🎂

---
Made with ❤️ by Isshan
